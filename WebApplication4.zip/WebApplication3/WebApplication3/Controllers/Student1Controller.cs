﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class Student1Controller : Controller
    {
        private UserDemoContext db = new UserDemoContext();

        // GET: /Student1/
        public ActionResult Index()
        {
            var student1 = db.Student1.Include(s => s.UserDemo);
            return View(student1.ToList());
        }

        // GET: /Student1/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Student1 student1 = db.Student1.Find(id);
            if (student1 == null)
            {
                return HttpNotFound();
            }
            return View(student1);
        }

        // GET: /Student1/Create
        public ActionResult Create()
        {
            ViewBag.UserdemoID = new SelectList(db.userdemo, "UserdemoID", "name");
            return View();
        }

        // POST: /Student1/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="Student1Id,UserdemoID,student1Name,student1Email,Genderlist")] Student1 student1)
        {
            if (ModelState.IsValid)
            {
                db.Student1.Add(student1);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.UserdemoID = new SelectList(db.userdemo, "UserdemoID", "name", student1.UserdemoID);
            return View(student1);
        }

        // GET: /Student1/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Student1 student1 = db.Student1.Find(id);
            if (student1 == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserdemoID = new SelectList(db.userdemo, "UserdemoID", "name", student1.UserdemoID);
            return View(student1);
        }

        // POST: /Student1/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="Student1Id,UserdemoID,student1Name,student1Email,Genderlist")] Student1 student1)
        {
            if (ModelState.IsValid)
            {
                db.Entry(student1).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.UserdemoID = new SelectList(db.userdemo, "UserdemoID", "name", student1.UserdemoID);
            return View(student1);
        }

        // GET: /Student1/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Student1 student1 = db.Student1.Find(id);
            if (student1 == null)
            {
                return HttpNotFound();
            }
            return View(student1);
        }

        // POST: /Student1/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Student1 student1 = db.Student1.Find(id);
            db.Student1.Remove(student1);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
