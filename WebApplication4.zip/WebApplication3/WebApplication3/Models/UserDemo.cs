﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace WebApplication3.Models
{
    public class UserDemo
    {
       
        public int UserdemoID { get; set; }
         [Required]
        [Display(Name="Enter Name")]
        public String name { get; set; }
         [Required]
         [Display(Name = "Enter Username")]
         public String username { get; set; }
         [Required]
         [DataType(DataType.Password)]
         public String password { get; set; }
    }
}