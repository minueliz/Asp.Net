﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace WebApplication3.Models
{
    public class Student1
    {
        public int Student1Id { get; set; }
        public int UserdemoID { get; set; }
        public virtual UserDemo UserDemo { get; set; }
        public String student1Name { get; set; }
         public String student1Email { get; set; }
         public Gender Genderlist { get; set; }
        
    }
    public enum Gender
    {
        Male,
        Female
    }
}