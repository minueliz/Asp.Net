﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace WebApplication3.Models
{
    public class UserDemoContext:DbContext
    {
        public UserDemoContext(): base("mycon")
        {
            DropCreateDatabaseIfModelChanges<UserDemoContext> d = new DropCreateDatabaseIfModelChanges<UserDemoContext>();
            Database.SetInitializer(d);
        }
        public DbSet<UserDemo> usersdemo { get; set; }
        }
}